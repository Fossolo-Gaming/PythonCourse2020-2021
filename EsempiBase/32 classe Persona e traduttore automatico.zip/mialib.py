import random

def saluta():
    print("Hello world!")
    
def lancia_dado(numero_facce = 6):
    # numero_facce è un paraetro facoltativo, che
    # viene settato a 6 se non specificato
    numero = random.randint(1,numero_facce)
    return numero

def fattoriale(n):
    
    # una funzione ricorsiva chiama sè stessa
    # per produrre il risultato da restituire
    
    if n == 0:
        return 1
    else:    
        # print("Hai chiesto il fattoriale di", n)
        return n*fattoriale(n-1)


class Persona():

    def __init__(self, nome, cognome):
        self.energia = 100
        self.nome = nome
        self.cognome = cognome
        self.soldi = 0
        print("Sono vivo, e mi chiamo", self.nome, self.cognome)

    def corri(self):
        
        self.energia -= 5
        if self.energia < 0:
            self.energia = 0
            
        if self.energia == 0:
            print(self.nome, "ha raggiunto il minimo dell'energia")
            
        # equivalente a :
        # self.energia = self.energia - 5
        # print("Energia", self.energia)

    def mangia(self):
        
        self.energia +=5
        
        if self.energia > 100:
            self.energia = 100
            
        if self.energia == 100:
            print(self.nome, "ha raggiunto il massimo dell'energia")

    def dormi(self, numero_ore):
        
        # per ora che dormo devo recuperare 10 punti di energia
        self.energia = self.energia + 10*numero_ore
        
        if self.energia > 100:
            self.energia = 100
            
        if self.energia == 100:
            print(self.nome, "ha raggiunto il massimo dell'energia")
        
    def guadagna(self, cifra):
        self.soldi = self.soldi + cifra
        print(self.nome, "ha in tasca:", self.soldi)
        # self.soldi += cifra # scrittura equivalente

    def spende(self, cifra):
        if self.soldi >= cifra:
            self.soldi = self.soldi - cifra
            print(self.nome, "ha in tasca:", self.soldi)
            # self.soldi += cifra # scrittura equivalente
        else:
            print(self.nome, "non ha abbastanza soldi per spendere:", cifra)

    def regala(self, destinatario, cifra):
        if self.soldi >= cifra:
            # chi regala diventa più povero
            self.spende(cifra)
            # chi riceve diventa più ricco
            destinatario.guadagna(cifra)
        else:
            print(self.nome, "non può regalare soldi a", destinatario.nome)
