# due modi diversi per importare tutto ciò che è definito nella libreria
# import mialib
from mialib import * # * = tutto

io = Persona("Nicola", "Bortolini")
# io è un oggetto della classe Persona

print(io.energia)
io.corri()
io.corri()
print(io.energia)

leonardo = Persona("Leonardo", "Bortolini")

for i in range(20):
    leonardo.corri()

leonardo.dormi(2)
print(leonardo.energia)

io.guadagna(10)
io.spende(40)

leonardo.guadagna(100)
leonardo.guadagna(10)
io.guadagna(50)

# voglio regalare 50 euro a Leonardo
io.regala(leonardo, 50)

leonardo.regala(io, 200)

