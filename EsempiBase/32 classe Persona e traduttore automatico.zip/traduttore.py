# per le parentesi graffe:
# { = ALT+123
# } = ALT+126
traduzioni_inglese = {
    'Ciao'      : 'Hello',
    'a'         : 'to',
    'tutti'     : 'everyone'
}

def traduci(frase):
    parole = frase.split()
    traduzione = ""
    for parola in parole:
        #print(parola)
        if parola in traduzioni_inglese:
            #print(traduzioni_inglese[parola])
            traduzione += traduzioni_inglese[parola] + " "

    traduzione.strip() # tolgo gli spazi
    print(traduzione)



testo = "Ciao a tutti"
traduci(testo)


#aggiungo un elemento al dizionario
traduzioni_inglese['Buongiorno'] = 'Goog morning'



traduci("Buongiorno e Ciao a tutti")

del traduzioni_inglese['Buongiorno'] # tolgo un elemento

traduci("Buongiorno e Ciao a tutti")
