traduzioni_inglese = {
    'ciao'      : 'Hello',
    'a'         : 'to',
    'al'        : 'to the',
    'corso'     : 'course',
    'benvenuti' : 'welcome',
    'tutti'     : 'everyone'
}

traduzioni_gattese = {
    'ciao'      : 'miao',
    'a'         : 'miiiao',
    'al'        : 'miaaao',
    'corso'     : 'miaooo',
    'benvenuti' : 'miaaaaao',
    'tutti'     : 'miaoaoaoao'
}

#print(traduzioni_inglese['Ciao'])
#print(traduzioni_gattese['Ciao'])


def traduci(frase, dizionario):
    parole = frase.split()
    for parola in parole:
        # print(parola)
        parola = parola.lower()
        print(dizionario[parola])


frase = "CIAO a tutti benvenuti al corso"
traduci(frase, traduzioni_inglese)
frase = "benvenuti a tutti ciao"
traduci(frase, traduzioni_gattese)

