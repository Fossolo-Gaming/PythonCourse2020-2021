# importo la libreria
from mialib import *

# scrittura alternativa
# import mialib

# provo la prima procedura della libreria
saluta()

# provo il lancio del dado
for i in range(10):
    n = lancia_dado(20)
    print(n)

# lancio il dado senza dirgli quante facce ha
# la procedura assume che sia un dado a 6 facce
print("------------------------")
for i in range(10):
    n = lancia_dado()
    print(n)


# calcolo il fattoriale di 10
x = fattoriale(10)
print(x)

# creo l'oggetto 'io' dalla classe 'Persona'
io = Persona()
io.corri()
io.corri()
io.corri()
# visualizzo la mia energia
print("la mia energia:",io.energia)
io.dormi(3)
print("la mia energia:",io.energia)

io.mangia()
print("la mia energia:",io.energia)

# creo un altro oggetto
amico = Persona()
amico.corri()
amico.dormi(5)
print("energia del mio amico:", amico.energia)

