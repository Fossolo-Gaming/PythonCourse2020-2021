import random

def saluta():
    print("Hello world!")
    
def lancia_dado(numero_facce = 6):
    # numero_facce è un paraetro facoltativo, che
    # viene settato a 6 se non specificato
    numero = random.randint(1,numero_facce)
    return numero

def fattoriale(n):
    
    # una funzione ricorsiva chiama sè stessa
    # per produrre il risultato da restituire
    
    if n == 0:
        return 1
    else:    
        # print("Hai chiesto il fattoriale di", n)
        return n*fattoriale(n-1)


class Persona():

    def __init__(self):
        print("Sono vivo!")
        self.energia = 100

    def corri(self):
        self.energia -= 5
        # equivalente a :
        # self.energia = self.energia - 5
        # print("Energia", self.energia)

    def mangia(self):
        self.energia +=5

    def dormi(self, numero_ore):
        # per ora che dormo devo recuperare 10 punti di energia
        self.energia = self.energia + 10*numero_ore
        
